(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0c-d9kfm_iceh._.css","static/chunks/node_modules_next_dist_20wefz_f1k6jn._.js","static/chunks/src_0m5y_omjf5eo7._.js","static/chunks/node_modules_next_0xpnkg-mg60il._.js","static/chunks/node_modules_@supabase_auth-js_dist_module_1vqrmkgvzhvl8._.js","static/chunks/node_modules_axios_lib_1yl9f_oq5xg9q._.js","static/chunks/node_modules_1ddftmo8z2hpf._.js"],
    source: "entry"
});

(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/src/app/jogos/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>JogosPage,
    "dynamic",
    ()=>dynamic
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/image-component.js [app-client] (ecmascript) <export Image as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Nav$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Nav.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Footer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Divisor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Divisor.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$GameCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/GameCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$loading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/loading.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Icons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$assets$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/assets.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mocks$2f$promos$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/mocks/promos.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$adulto$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/adulto/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$hardwareGiftCard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/hardwareGiftCard.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$itad$2e$ts$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/itad.ts/index.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const dynamic = 'force-dynamic';
// Ícones dedicados para cada seção de filtro
function StatusIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        className: "size-4",
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "12",
                cy: "12",
                r: "9"
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "m9 12 2 2 4-4"
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/jogos/page.tsx",
        lineNumber: 28,
        columnNumber: 5
    }, this);
}
_c = StatusIcon;
function PriceIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        className: "size-4",
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                x1: "12",
                y1: "2",
                x2: "12",
                y2: "22"
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 56,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/jogos/page.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
_c1 = PriceIcon;
function DiscountIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        className: "size-4",
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("line", {
                x1: "19",
                y1: "5",
                x2: "5",
                y2: "19"
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 74,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "6.5",
                cy: "6.5",
                r: "2.5"
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 75,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "17.5",
                cy: "17.5",
                r: "2.5"
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/jogos/page.tsx",
        lineNumber: 64,
        columnNumber: 5
    }, this);
}
_c2 = DiscountIcon;
function ContentIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        className: "size-4",
        ...props,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"
        }, void 0, false, {
            fileName: "[project]/src/app/jogos/page.tsx",
            lineNumber: 93,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/jogos/page.tsx",
        lineNumber: 83,
        columnNumber: 5
    }, this);
}
_c3 = ContentIcon;
function HardwareIcon(props) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        strokeWidth: "2.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        className: "size-4",
        ...props,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                x: "2",
                y: "6",
                width: "20",
                height: "12",
                rx: "2"
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 110,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M6 12h4m-2-2v4"
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 111,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "17",
                cy: "10",
                r: "1",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 112,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "15",
                cy: "14",
                r: "1",
                fill: "currentColor"
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 113,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/jogos/page.tsx",
        lineNumber: 100,
        columnNumber: 5
    }, this);
}
_c4 = HardwareIcon;
// Adaptador para converter dados da API no tipo esperado pelo GameCard
const paraCard = (j)=>{
    const coverUrl = j.capa ?? (j.itad_id ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$itad$2e$ts$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["urlCapaItad"])(String(j.itad_id)) : null);
    if ('melhorPreco' in j || 'status' in j) {
        return {
            id: j.id ?? j.id_jogo ?? 0,
            name: j.titulo ?? j.name ?? 'Sem título',
            store: j.loja ?? (j.melhorPreco === null ? 'Sem oferta' : 'Loja parceira'),
            discount: j.desconto ?? 0,
            originalPrice: j.precoOriginal ?? 0,
            price: j.melhorPreco,
            cover: coverUrl
        };
    }
    const promocoes = j.promocoes || [];
    const ofertasValidas = promocoes.filter((p)=>p.valor_atual !== null && p.valor_atual !== undefined);
    if (ofertasValidas.length === 0) {
        return {
            id: j.id_jogo ?? j.id ?? 0,
            name: j.titulo ?? j.name ?? 'Sem título',
            store: 'Sem oferta',
            discount: 0,
            originalPrice: 0,
            price: null,
            cover: coverUrl
        };
    }
    const melhorPromo = ofertasValidas.reduce((min, p)=>{
        return p.valor_atual < min.valor_atual ? p : min;
    }, ofertasValidas[0]);
    const loja = melhorPromo?.loja ? Array.isArray(melhorPromo.loja) ? melhorPromo.loja[0]?.nome : melhorPromo.loja.nome : 'Loja parceira';
    const price = melhorPromo.valor_atual ?? null;
    const discount = melhorPromo.percentual_desconto ?? 0;
    const originalPrice = discount > 0 && price !== null ? +(price / (1 - discount / 100)).toFixed(2) : price;
    return {
        id: j.id_jogo ?? j.id ?? 0,
        name: j.titulo ?? j.name ?? 'Sem título',
        store: loja ?? 'Loja parceira',
        discount,
        originalPrice,
        price,
        cover: coverUrl
    };
};
// Nomes (em minúsculas) das lojas que têm oferta para o jogo
function lojasDoJogo(j) {
    const promocoes = Array.isArray(j.promocoes) ? j.promocoes : [];
    const nomes = promocoes.map((p)=>Array.isArray(p.loja) ? p.loja[0]?.nome : p.loja?.nome).filter(Boolean);
    if (nomes.length === 0 && j.loja) nomes.push(j.loja);
    return nomes.map((n)=>String(n).toLowerCase());
}
// Aplica no resultado da busca os mesmos filtros do painel lateral (Estado, Preços, Descontos, Lojas e Hardware/Consoles)
function passaNosFiltros(j, f) {
    if (!f.incluirHardware && (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$hardwareGiftCard$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ehConsoleOuGiftCard"])(j.titulo ?? j.name)) {
        return false;
    }
    const preco = j.melhorPreco ?? null;
    if (f.status === 'GRATIS') {
        const gratis = j.status === 'FREE_TO_PLAY' || j.status === 'PROMO_GRATIS' || preco === 0;
        if (!gratis) return false;
    }
    if (f.status === 'INDISPONIVEL') {
        if (!(j.status === 'INDISPONIVEL' || preco === null)) return false;
    }
    if (f.precoMax !== null && (preco === null || preco > f.precoMax)) return false;
    if (f.corteMin !== null) {
        const promocoes = Array.isArray(j.promocoes) ? j.promocoes : [];
        const descontos = promocoes.map((p)=>Number(p.percentual_desconto ?? 0)).concat(promocoes.length === 0 ? [
            Number(j.desconto ?? 0)
        ] : []);
        if (!descontos.some((d)=>d >= f.corteMin)) return false;
    }
    if (f.lojas.length > 0) {
        const escolhidas = f.lojas.map((l)=>l.toLowerCase());
        if (!lojasDoJogo(j).some((nome)=>escolhidas.includes(nome))) return false;
    }
    return true;
}
// Botão em formato de Chip compacto
function Chip({ label, ativa, onClick }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        onClick: onClick,
        "aria-pressed": ativa,
        className: `cursor-pointer rounded-full px-3.5 py-1.5 font-head text-xs font-bold transition-all active:scale-95 ${ativa ? 'bg-bp-primary text-bp-neutral shadow-sm' : 'border border-[#3d322e] bg-bp-neutral text-bp-muted hover:border-bp-primary/50 hover:text-white'}`,
        children: label
    }, void 0, false, {
        fileName: "[project]/src/app/jogos/page.tsx",
        lineNumber: 242,
        columnNumber: 5
    }, this);
}
_c5 = Chip;
// Grupo de filtros sanfonado (Accordion)
function Grupo({ titulo, icone, children, abertoPadrao = true }) {
    _s();
    const [aberto, setAberto] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(abertoPadrao);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col border-b border-[#3d322e]/60 pb-3.5 last:border-none last:pb-0",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: ()=>setAberto(!aberto),
                className: "flex w-full cursor-pointer items-center justify-between py-1.5 text-left font-head text-sm font-extrabold text-bp-primary transition hover:opacity-80",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "flex items-center gap-2 [&>svg]:size-4",
                        children: [
                            icone,
                            titulo
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/jogos/page.tsx",
                        lineNumber: 278,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `text-[10px] text-bp-muted transition-transform duration-200 ${aberto ? 'rotate-180' : ''}`,
                        children: "▼"
                    }, void 0, false, {
                        fileName: "[project]/src/app/jogos/page.tsx",
                        lineNumber: 282,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 273,
                columnNumber: 7
            }, this),
            aberto && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-2 flex flex-wrap gap-1.5",
                children: children
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 291,
                columnNumber: 18
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/jogos/page.tsx",
        lineNumber: 272,
        columnNumber: 5
    }, this);
}
_s(Grupo, "luzSSh0MY+vcCHRfDFGyE4/aLes=");
_c6 = Grupo;
function ConteudoJogos() {
    _s1();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const termoNaUrl = (searchParams.get('search') || searchParams.get('busca') || '').trim();
    const modoNaUrl = searchParams.get('modo') || 'nativa';
    const [resultadoBusca, setResultadoBusca] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [carregandoBusca, setCarregandoBusca] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [erroBusca, setErroBusca] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [filtroStatus, setFiltroStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])('TODOS');
    const [precoMax, setPrecoMax] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [corteMin, setCorteMin] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [lojas, setLojas] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [pagina, setPagina] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(1);
    const [adulto, setAdulto] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [incluirHardware, setIncluirHardware] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [filtrosMobileAbertos, setFiltrosMobileAbertos] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [jogos, setJogos] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [total, setTotal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [carregando, setCarregando] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [erroCatalogo, setErroCatalogo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const totalPaginas = Math.max(1, Math.ceil(total / __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mocks$2f$promos$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PER_PAGE"]));
    const atual = Math.min(pagina, totalPaginas);
    // Resultado da busca com os filtros do painel aplicados
    const resultadoFiltrado = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ConteudoJogos.useMemo[resultadoFiltrado]": ()=>resultadoBusca.filter({
                "ConteudoJogos.useMemo[resultadoFiltrado]": (j)=>passaNosFiltros(j, {
                        status: filtroStatus,
                        precoMax,
                        corteMin,
                        lojas,
                        incluirHardware
                    })
            }["ConteudoJogos.useMemo[resultadoFiltrado]"])
    }["ConteudoJogos.useMemo[resultadoFiltrado]"], [
        resultadoBusca,
        filtroStatus,
        precoMax,
        corteMin,
        lojas,
        incluirHardware
    ]);
    const escolher = (definir, valorAtual, v)=>{
        definir(valorAtual === v ? null : v);
        setPagina(1);
    };
    const alternarLoja = (loja)=>{
        setLojas((l)=>l.includes(loja) ? l.filter((x)=>x !== loja) : [
                ...l,
                loja
            ]);
        setPagina(1);
    };
    const alternarAdulto = ()=>{
        if (!adulto && !window.confirm('Mostrar jogos com conteúdo adulto? Confirme que você tem 18 anos ou mais.')) {
            return;
        }
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$adulto$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["definirAdultoNoNavegador"])(!adulto);
        setAdulto(!adulto);
        setPagina(1);
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConteudoJogos.useEffect": ()=>{
            setAdulto((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$adulto$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["adultoAtivoNoNavegador"])());
        }
    }["ConteudoJogos.useEffect"], []);
    // Busca por termo (os filtros do painel são aplicados depois, sobre o resultado)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConteudoJogos.useEffect": ()=>{
            if (!termoNaUrl) {
                setResultadoBusca([]);
                setErroBusca(null);
                setCarregandoBusca(false);
                return;
            }
            const controller = new AbortController();
            setCarregandoBusca(true);
            setErroBusca(null);
            const params = new URLSearchParams();
            params.set('busca', termoNaUrl);
            params.set('modo', modoNaUrl);
            if (incluirHardware) params.set('hardware', '1');
            fetch(`/api/v1/games?${params.toString()}`, {
                signal: controller.signal
            }).then({
                "ConteudoJogos.useEffect": async (res)=>{
                    const dados = await res.json().catch({
                        "ConteudoJogos.useEffect": ()=>null
                    }["ConteudoJogos.useEffect"]);
                    if (!res.ok) {
                        throw new Error(dados?.detalhes || dados?.erro || dados?.error || `Erro HTTP: ${res.status}`);
                    }
                    if (!controller.signal.aborted) {
                        const resultados = dados?.jogosEncontrados ?? dados?.jogos ?? [];
                        setResultadoBusca(Array.isArray(resultados) ? resultados : []);
                    }
                }
            }["ConteudoJogos.useEffect"]).catch({
                "ConteudoJogos.useEffect": (erro)=>{
                    if (!controller.signal.aborted && erro.name !== 'AbortError') {
                        setErroBusca(erro instanceof Error ? erro.message : 'Erro ao pesquisar o jogo.');
                    }
                }
            }["ConteudoJogos.useEffect"]).finally({
                "ConteudoJogos.useEffect": ()=>{
                    if (!controller.signal.aborted) {
                        setCarregandoBusca(false);
                    }
                }
            }["ConteudoJogos.useEffect"]);
            return ({
                "ConteudoJogos.useEffect": ()=>controller.abort()
            })["ConteudoJogos.useEffect"];
        }
    }["ConteudoJogos.useEffect"], [
        termoNaUrl,
        modoNaUrl,
        adulto,
        incluirHardware
    ]);
    // Busca do catálogo padrão paginado
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConteudoJogos.useEffect": ()=>{
            if (termoNaUrl) return;
            const controller = new AbortController();
            const params = new URLSearchParams({
                page: String(pagina),
                limit: String(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mocks$2f$promos$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PER_PAGE"])
            });
            if (filtroStatus !== 'TODOS') params.set('status', filtroStatus);
            if (precoMax !== null) params.set('price', String(precoMax));
            if (corteMin !== null) params.set('discount', String(corteMin));
            if (lojas.length) params.set('store', lojas.join(','));
            if (incluirHardware) params.set('hardware', '1');
            setCarregando(true);
            setErroCatalogo(null);
            fetch(`/api/v1/games?${params.toString()}`, {
                signal: controller.signal
            }).then({
                "ConteudoJogos.useEffect": async (res)=>{
                    const json = await res.json().catch({
                        "ConteudoJogos.useEffect": ()=>null
                    }["ConteudoJogos.useEffect"]);
                    if (!res.ok) {
                        throw new Error(json?.error ?? 'Erro ao carregar as ofertas.');
                    }
                    if (!controller.signal.aborted) {
                        setJogos(json.jogos ?? []);
                        setTotal(json.total ?? 0);
                    }
                }
            }["ConteudoJogos.useEffect"]).catch({
                "ConteudoJogos.useEffect": (e)=>{
                    if (!controller.signal.aborted && e.name !== 'AbortError') {
                        setErroCatalogo(e.message);
                    }
                }
            }["ConteudoJogos.useEffect"]).finally({
                "ConteudoJogos.useEffect": ()=>{
                    if (!controller.signal.aborted) {
                        setCarregando(false);
                    }
                }
            }["ConteudoJogos.useEffect"]);
            return ({
                "ConteudoJogos.useEffect": ()=>controller.abort()
            })["ConteudoJogos.useEffect"];
        }
    }["ConteudoJogos.useEffect"], [
        termoNaUrl,
        filtroStatus,
        precoMax,
        corteMin,
        lojas,
        pagina,
        adulto,
        incluirHardware
    ]);
    const executarBusca = (novoTermo, novoModo = modoNaUrl)=>{
        const termo = novoTermo.trim();
        setPagina(1);
        if (termo) {
            router.push(`/jogos?search=${encodeURIComponent(termo)}&modo=${novoModo}`);
        } else {
            router.push(`/jogos?modo=${novoModo}`);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex min-h-screen flex-col bg-bp-bg overflow-x-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "sticky top-0 z-50 w-full shrink-0",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Nav$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    logado: true,
                    valorBusca: termoNaUrl,
                    modoInicial: modoNaUrl,
                    onSearch: executarBusca
                }, void 0, false, {
                    fileName: "[project]/src/app/jogos/page.tsx",
                    lineNumber: 472,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 471,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "relative flex flex-1 flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "px-[55px] pt-2.5 max-[640px]:px-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                            className: "flex items-center gap-3 p-5 font-head text-[32px] font-extrabold text-bp-primary max-[640px]:text-2xl",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TagIcon"], {
                                    width: 56,
                                    height: 56
                                }, void 0, false, {
                                    fileName: "[project]/src/app/jogos/page.tsx",
                                    lineNumber: 484,
                                    columnNumber: 13
                                }, this),
                                " Ofertas do Momento"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/jogos/page.tsx",
                            lineNumber: 483,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/jogos/page.tsx",
                        lineNumber: 482,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Divisor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        cor: "#3d322e",
                        className: "mx-[55px] my-2"
                    }, void 0, false, {
                        fileName: "[project]/src/app/jogos/page.tsx",
                        lineNumber: 489,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative z-[1] flex flex-1 items-start gap-8 px-[55px] pb-0 pt-6 max-[1100px]:flex-col max-[1100px]:items-center max-[640px]:px-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex w-full items-center justify-between min-[1101px]:hidden",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>setFiltrosMobileAbertos((v)=>!v),
                                    className: "flex w-full items-center justify-between rounded-2xl border-2 border-[#3d322e] bg-bp-nav px-4 py-3 font-head text-sm font-bold text-bp-primary shadow-md active:scale-95 transition",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreIcon"], {
                                                    className: "size-4"
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/jogos/page.tsx",
                                                    lineNumber: 500,
                                                    columnNumber: 17
                                                }, this),
                                                filtrosMobileAbertos ? 'Ocultar Filtros' : 'Filtrar Ofertas e Categorias'
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/jogos/page.tsx",
                                            lineNumber: 499,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs text-bp-muted",
                                            children: filtrosMobileAbertos ? '▲' : '▼'
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/jogos/page.tsx",
                                            lineNumber: 503,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/jogos/page.tsx",
                                    lineNumber: 494,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/jogos/page.tsx",
                                lineNumber: 493,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `w-full max-w-[280px] shrink-0 flex-col justify-between self-stretch max-[1100px]:max-w-full ${filtrosMobileAbertos ? 'flex' : 'hidden min-[1101px]:flex'}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                                        "aria-label": "Filtros",
                                        className: "flex w-full flex-col gap-4 rounded-3xl border-2 border-[#3d322e] bg-bp-nav p-5 shadow-lg",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Grupo, {
                                                titulo: "Estado",
                                                icone: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StatusIcon, {}, void 0, false, {
                                                    fileName: "[project]/src/app/jogos/page.tsx",
                                                    lineNumber: 519,
                                                    columnNumber: 45
                                                }, this),
                                                abertoPadrao: true,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Chip, {
                                                        label: "Todos",
                                                        ativa: filtroStatus === 'TODOS',
                                                        onClick: ()=>{
                                                            setFiltroStatus('TODOS');
                                                            setPagina(1);
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/jogos/page.tsx",
                                                        lineNumber: 520,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Chip, {
                                                        label: "Grátis",
                                                        ativa: filtroStatus === 'GRATIS',
                                                        onClick: ()=>{
                                                            setFiltroStatus(filtroStatus === 'GRATIS' ? 'TODOS' : 'GRATIS');
                                                            setPagina(1);
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/jogos/page.tsx",
                                                        lineNumber: 528,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Chip, {
                                                        label: "Indisponível",
                                                        ativa: filtroStatus === 'INDISPONIVEL',
                                                        onClick: ()=>{
                                                            setFiltroStatus(filtroStatus === 'INDISPONIVEL' ? 'TODOS' : 'INDISPONIVEL');
                                                            setPagina(1);
                                                        }
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/jogos/page.tsx",
                                                        lineNumber: 536,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/jogos/page.tsx",
                                                lineNumber: 519,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Grupo, {
                                                titulo: "Preços",
                                                icone: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(PriceIcon, {}, void 0, false, {
                                                    fileName: "[project]/src/app/jogos/page.tsx",
                                                    lineNumber: 546,
                                                    columnNumber: 45
                                                }, this),
                                                abertoPadrao: true,
                                                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mocks$2f$promos$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PRICE_FILTERS"].map((v)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Chip, {
                                                        label: `< R$ ${v}`,
                                                        ativa: precoMax === v,
                                                        onClick: ()=>escolher(setPrecoMax, precoMax, v)
                                                    }, v, false, {
                                                        fileName: "[project]/src/app/jogos/page.tsx",
                                                        lineNumber: 548,
                                                        columnNumber: 19
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/jogos/page.tsx",
                                                lineNumber: 546,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Grupo, {
                                                titulo: "Descontos",
                                                icone: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DiscountIcon, {}, void 0, false, {
                                                    fileName: "[project]/src/app/jogos/page.tsx",
                                                    lineNumber: 557,
                                                    columnNumber: 48
                                                }, this),
                                                abertoPadrao: false,
                                                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mocks$2f$promos$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CUT_FILTERS"].map((v)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Chip, {
                                                        label: `-${v}% ou +`,
                                                        ativa: corteMin === v,
                                                        onClick: ()=>escolher(setCorteMin, corteMin, v)
                                                    }, v, false, {
                                                        fileName: "[project]/src/app/jogos/page.tsx",
                                                        lineNumber: 559,
                                                        columnNumber: 19
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/jogos/page.tsx",
                                                lineNumber: 557,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Grupo, {
                                                titulo: "Lojas",
                                                icone: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["StoreIcon"], {}, void 0, false, {
                                                    fileName: "[project]/src/app/jogos/page.tsx",
                                                    lineNumber: 568,
                                                    columnNumber: 44
                                                }, this),
                                                abertoPadrao: false,
                                                children: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mocks$2f$promos$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["STORES"].map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Chip, {
                                                        label: s,
                                                        ativa: lojas.includes(s),
                                                        onClick: ()=>alternarLoja(s)
                                                    }, s, false, {
                                                        fileName: "[project]/src/app/jogos/page.tsx",
                                                        lineNumber: 570,
                                                        columnNumber: 19
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/jogos/page.tsx",
                                                lineNumber: 568,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Grupo, {
                                                titulo: "Conteúdo",
                                                icone: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContentIcon, {}, void 0, false, {
                                                    fileName: "[project]/src/app/jogos/page.tsx",
                                                    lineNumber: 579,
                                                    columnNumber: 47
                                                }, this),
                                                abertoPadrao: false,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Chip, {
                                                    label: "18+ Adulto",
                                                    ativa: adulto,
                                                    onClick: alternarAdulto
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/jogos/page.tsx",
                                                    lineNumber: 580,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/jogos/page.tsx",
                                                lineNumber: 579,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Grupo, {
                                                titulo: "Outros",
                                                icone: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(HardwareIcon, {}, void 0, false, {
                                                    fileName: "[project]/src/app/jogos/page.tsx",
                                                    lineNumber: 587,
                                                    columnNumber: 45
                                                }, this),
                                                abertoPadrao: false,
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Chip, {
                                                    label: "Consoles & Gift Cards",
                                                    ativa: incluirHardware,
                                                    onClick: ()=>{
                                                        setIncluirHardware(!incluirHardware);
                                                        setPagina(1);
                                                    }
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/jogos/page.tsx",
                                                    lineNumber: 588,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/jogos/page.tsx",
                                                lineNumber: 587,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/jogos/page.tsx",
                                        lineNumber: 515,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-auto flex items-end justify-start pt-6 max-[1100px]:hidden",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__["default"], {
                                            src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$assets$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["palmeira"],
                                            alt: "",
                                            width: 520,
                                            height: 520,
                                            className: "pointer-events-none -ml-[160px] -mb-1 w-[520px] max-w-none object-contain select-none"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/jogos/page.tsx",
                                            lineNumber: 601,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/jogos/page.tsx",
                                        lineNumber: 600,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/jogos/page.tsx",
                                lineNumber: 510,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                                "aria-label": "Ofertas",
                                className: "flex w-full flex-1 flex-col items-center gap-8 pb-10",
                                children: [
                                    termoNaUrl ? carregandoBusca ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$loading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        mensagem: modoNaUrl === 'ia' ? 'Realizando busca profunda com IA...' : 'Pesquisando jogos no catálogo...'
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/jogos/page.tsx",
                                        lineNumber: 618,
                                        columnNumber: 17
                                    }, this) : erroBusca ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        role: "alert",
                                        className: "py-16 text-center text-red-400",
                                        children: erroBusca
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/jogos/page.tsx",
                                        lineNumber: 626,
                                        columnNumber: 17
                                    }, this) : resultadoBusca.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "py-16 text-center text-bp-muted",
                                        children: "Nenhum jogo relacionado foi encontrado."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/jogos/page.tsx",
                                        lineNumber: 630,
                                        columnNumber: 17
                                    }, this) : resultadoFiltrado.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "py-16 text-center text-bp-muted",
                                        children: "Nenhum jogo da busca corresponde aos filtros selecionados."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/jogos/page.tsx",
                                        lineNumber: 634,
                                        columnNumber: 17
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        className: "grid w-full list-none auto-rows-fr grid-cols-2 gap-2 sm:gap-[13px] md:grid-cols-2 lg:grid-cols-3",
                                        children: resultadoFiltrado.map((jogo, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "h-full",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: `/jogos/${jogo.id_jogo ?? jogo.id}`,
                                                    className: "block h-full transition hover:brightness-110 active:scale-95",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$GameCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        game: paraCard(jogo)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/jogos/page.tsx",
                                                        lineNumber: 645,
                                                        columnNumber: 25
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/jogos/page.tsx",
                                                    lineNumber: 641,
                                                    columnNumber: 23
                                                }, this)
                                            }, `${jogo.id_jogo ?? jogo.id ?? 'busca'}-${index}`, false, {
                                                fileName: "[project]/src/app/jogos/page.tsx",
                                                lineNumber: 640,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/jogos/page.tsx",
                                        lineNumber: 638,
                                        columnNumber: 17
                                    }, this) : carregando ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$loading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        mensagem: "Carregando ofertas..."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/jogos/page.tsx",
                                        lineNumber: 652,
                                        columnNumber: 15
                                    }, this) : erroCatalogo ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        role: "alert",
                                        className: "py-16 text-center text-red-400",
                                        children: erroCatalogo
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/jogos/page.tsx",
                                        lineNumber: 654,
                                        columnNumber: 15
                                    }, this) : jogos.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "py-16 text-center text-bp-muted",
                                        children: "Nenhuma oferta encontrada com esses filtros."
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/jogos/page.tsx",
                                        lineNumber: 658,
                                        columnNumber: 15
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                        className: "grid w-full list-none auto-rows-fr grid-cols-2 gap-2 sm:gap-[13px] md:grid-cols-2 lg:grid-cols-3",
                                        children: jogos.map((j, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                className: "h-full",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    href: `/jogos/${j.id ?? j.id_jogo}`,
                                                    className: "block h-full transition hover:brightness-110 active:scale-95",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$GameCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        game: paraCard(j)
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/app/jogos/page.tsx",
                                                        lineNumber: 669,
                                                        columnNumber: 23
                                                    }, this)
                                                }, void 0, false, {
                                                    fileName: "[project]/src/app/jogos/page.tsx",
                                                    lineNumber: 665,
                                                    columnNumber: 21
                                                }, this)
                                            }, `${j.id ?? j.id_jogo ?? 'catalogo'}-${index}`, false, {
                                                fileName: "[project]/src/app/jogos/page.tsx",
                                                lineNumber: 664,
                                                columnNumber: 19
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/jogos/page.tsx",
                                        lineNumber: 662,
                                        columnNumber: 15
                                    }, this),
                                    !termoNaUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                                        "aria-label": "Paginação",
                                        className: "flex items-center gap-[73px] rounded-3xl bg-bp-nav p-2.5 max-[640px]:gap-10",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>setPagina(atual - 1),
                                                disabled: atual === 1,
                                                "aria-label": "Página anterior",
                                                className: "h-[49px] w-9 cursor-pointer bg-bp-primary transition hover:brightness-110 active:scale-95 disabled:cursor-default disabled:opacity-40 [clip-path:polygon(100%_0,100%_100%,0_50%)]"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/jogos/page.tsx",
                                                lineNumber: 681,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "sr-only",
                                                "aria-live": "polite",
                                                children: [
                                                    "Página ",
                                                    atual,
                                                    " de ",
                                                    totalPaginas
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/app/jogos/page.tsx",
                                                lineNumber: 689,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>setPagina(atual + 1),
                                                disabled: atual === totalPaginas,
                                                "aria-label": "Próxima página",
                                                className: "h-[49px] w-9 cursor-pointer bg-bp-primary transition hover:brightness-110 active:scale-95 disabled:cursor-default disabled:opacity-40 [clip-path:polygon(0_0,100%_50%,0_100%)]"
                                            }, void 0, false, {
                                                fileName: "[project]/src/app/jogos/page.tsx",
                                                lineNumber: 693,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/app/jogos/page.tsx",
                                        lineNumber: 677,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/app/jogos/page.tsx",
                                lineNumber: 612,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/jogos/page.tsx",
                        lineNumber: 491,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 480,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/app/jogos/page.tsx",
                lineNumber: 706,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/jogos/page.tsx",
        lineNumber: 470,
        columnNumber: 5
    }, this);
}
_s1(ConteudoJogos, "8tmhkYlBIkGIQIt5epVUiTp4mcw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c7 = ConteudoJogos;
function JogosPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$loading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            mensagem: "Carregando página..."
        }, void 0, false, {
            fileName: "[project]/src/app/jogos/page.tsx",
            lineNumber: 713,
            columnNumber: 25
        }, this),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConteudoJogos, {}, void 0, false, {
            fileName: "[project]/src/app/jogos/page.tsx",
            lineNumber: 714,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/jogos/page.tsx",
        lineNumber: 713,
        columnNumber: 5
    }, this);
}
_c8 = JogosPage;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8;
__turbopack_context__.k.register(_c, "StatusIcon");
__turbopack_context__.k.register(_c1, "PriceIcon");
__turbopack_context__.k.register(_c2, "DiscountIcon");
__turbopack_context__.k.register(_c3, "ContentIcon");
__turbopack_context__.k.register(_c4, "HardwareIcon");
__turbopack_context__.k.register(_c5, "Chip");
__turbopack_context__.k.register(_c6, "Grupo");
__turbopack_context__.k.register(_c7, "ConteudoJogos");
__turbopack_context__.k.register(_c8, "JogosPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Divisor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Divisor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
// src/components/Divisor.tsx
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mocks$2f$tema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/mocks/tema.ts [app-client] (ecmascript)");
;
;
function Divisor({ tipo = 'secao', cor, className = '' }) {
    if (tipo === 'fino') {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: `w-full border-b ${!cor ? 'border-bp-muted/20' : ''} ${className}`,
            style: cor ? {
                borderColor: cor
            } : undefined
        }, void 0, false, {
            fileName: "[project]/src/components/Divisor.tsx",
            lineNumber: 21,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `mx-2.5 h-[5px] rounded-[2px] ${className}`,
        style: {
            background: cor || __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mocks$2f$tema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tema"].divisorForte
        }
    }, void 0, false, {
        fileName: "[project]/src/components/Divisor.tsx",
        lineNumber: 29,
        columnNumber: 5
    }, this);
}
_c = Divisor;
var _c;
__turbopack_context__.k.register(_c, "Divisor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Footer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Footer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/image-component.js [app-client] (ecmascript) <export Image as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$assets$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/assets.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mocks$2f$tema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/mocks/tema.ts [app-client] (ecmascript)");
;
;
;
;
;
function Footer() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "w-full bg-bp-nav",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-[5px] w-full",
                style: {
                    background: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mocks$2f$tema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tema"].divisor
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Footer.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between gap-10 px-[23px] pb-5 pt-4 max-[1100px]:flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex w-[400px] max-w-full flex-col gap-[11px]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative h-[63px] w-48 overflow-hidden",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__["default"], {
                                    src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$assets$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logo"],
                                    alt: "BananaPrice",
                                    width: 242,
                                    height: 81,
                                    className: "absolute -left-4 -top-1.5 h-[81px] w-[242px] max-w-none object-cover"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Footer.tsx",
                                    lineNumber: 22,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Footer.tsx",
                                lineNumber: 21,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs leading-[19.5px] text-bp-muted",
                                children: "BananaPrice é uma ferramenta independente feita por e para gamers brasileiros. Monitoramos lojas oficiais, atualizando a cada 24 horas para garantir que você compre seus títulos favoritos pelo menor preço real."
                            }, void 0, false, {
                                fileName: "[project]/src/components/Footer.tsx",
                                lineNumber: 30,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Footer.tsx",
                        lineNumber: 20,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex w-[384px] max-w-full flex-col gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h5", {
                                className: "font-head text-xs font-bold uppercase tracking-[.6px] text-bp-primary",
                                children: "Transparência"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Footer.tsx",
                                lineNumber: 36,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                className: "flex list-none flex-col gap-1.5 text-xs text-[#8d7b74]",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/termos-de-uso",
                                            className: "hover:text-bp-muted transition",
                                            children: "Termos de Uso"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Footer.tsx",
                                            lineNumber: 41,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Footer.tsx",
                                        lineNumber: 40,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/politica-de-privacidade",
                                            className: "hover:text-bp-muted transition",
                                            children: "Política de Privacidade"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Footer.tsx",
                                            lineNumber: 46,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Footer.tsx",
                                        lineNumber: 45,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/contato-api",
                                            className: "hover:text-bp-muted transition",
                                            children: "Contato & API Pública"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Footer.tsx",
                                            lineNumber: 51,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Footer.tsx",
                                        lineNumber: 50,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Footer.tsx",
                                lineNumber: 39,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Footer.tsx",
                        lineNumber: 35,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "w-[384px] max-w-full text-xs leading-[19.5px] text-[#8d7b74]",
                        children: [
                            "Informações e dados de preços coletados através da IsThereAnyDeal API. Para mais informações, acesse",
                            ' ',
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "https://isthereanydeal.com",
                                target: "_blank",
                                rel: "noreferrer",
                                className: "text-[#d1c7bd] underline",
                                children: "IsThereAnyDeal.com"
                            }, void 0, false, {
                                fileName: "[project]/src/components/Footer.tsx",
                                lineNumber: 60,
                                columnNumber: 11
                            }, this),
                            "."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Footer.tsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Footer.tsx",
                lineNumber: 19,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-t-2 border-bp-muted/35 px-[23px] pb-3.5 pt-2.5 text-sm text-bp-muted/70",
                children: "© 2026 BananaPrice. Todos os direitos reservados. Marcas e imagens são propriedade de suas respectivas desenvolvedoras e editoras."
            }, void 0, false, {
                fileName: "[project]/src/components/Footer.tsx",
                lineNumber: 72,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Footer.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
_c = Footer;
var _c;
__turbopack_context__.k.register(_c, "Footer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/GameCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GameCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/image-component.js [app-client] (ecmascript) <export Image as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$assets$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/assets.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
const brl = (v)=>{
    if (v === null || v === undefined) return '';
    return v.toLocaleString('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    });
};
function GameCard({ game, variant = 'default' }) {
    _s();
    const wide = variant === 'wide';
    const [falhou, setFalhou] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GameCard.useEffect": ()=>setFalhou(false)
    }["GameCard.useEffect"], [
        game.cover
    ]);
    const capaRemota = typeof game.cover === 'string' && game.cover !== '' && !falhou;
    const src = capaRemota ? game.cover : !falhou && game.cover ? game.cover : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$assets$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["capaExemplo"];
    const isGratis = game.price === 0;
    const isIndisponivel = game.price === null || game.price === undefined;
    const isPromo100 = isGratis && game.discount === 100;
    const temDesconto = typeof game.price === 'number' && game.price > 0 && game.discount > 0;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        className: `relative flex h-full flex-col rounded-[13px] bg-bp-neutral transition-transform duration-150 ${wide ? 'max-w-[586px] flex-1 px-3 pb-3.5 pt-2 sm:px-[17px] sm:pb-5 sm:pt-[11px]' : 'p-2.5 sm:px-4 sm:pb-4 sm:pt-[11px]'}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `relative shrink-0 overflow-hidden rounded-[8px] sm:rounded-[10px] bg-[#111] ${wide ? 'aspect-[554/201]' : 'aspect-[253/214]'}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__["default"], {
                        src: src,
                        alt: game.name,
                        fill: true,
                        sizes: "(max-width: 640px) 50vw, (max-width: 1100px) 33vw, 283px",
                        className: "object-cover",
                        unoptimized: capaRemota,
                        onError: ()=>setFalhou(true)
                    }, void 0, false, {
                        fileName: "[project]/src/components/GameCard.tsx",
                        lineNumber: 57,
                        columnNumber: 9
                    }, this),
                    isPromo100 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "absolute bottom-0 right-0 bg-red-600 py-1 pl-4 pr-2 font-head text-sm font-extrabold text-white [clip-path:polygon(20%_0,100%_0,100%_100%,0_100%)] sm:py-2.5 sm:pl-7 sm:pr-3.5 sm:text-xl",
                        children: "-100%"
                    }, void 0, false, {
                        fileName: "[project]/src/components/GameCard.tsx",
                        lineNumber: 69,
                        columnNumber: 11
                    }, this) : isGratis ? /* Badge de Grátis Permanente (Free to Play) */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "absolute bottom-0 right-0 bg-green-500 py-1 pl-3.5 pr-2 font-head text-[10px] font-black text-black tracking-wider [clip-path:polygon(20%_0,100%_0,100%_100%,0_100%)] sm:py-2 sm:pl-6 sm:pr-3 sm:text-xs",
                        children: "GRÁTIS"
                    }, void 0, false, {
                        fileName: "[project]/src/components/GameCard.tsx",
                        lineNumber: 74,
                        columnNumber: 11
                    }, this) : temDesconto ? /* Badge de Desconto Padrão (para jogos pagos) */ /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "absolute bottom-0 right-0 bg-bp-primary py-1 pl-4 pr-2 font-head text-xs font-extrabold text-bp-neutral [clip-path:polygon(20%_0,100%_0,100%_100%,0_100%)] sm:py-2.5 sm:pl-7 sm:pr-3.5 sm:text-xl",
                        children: [
                            "-",
                            game.discount,
                            "%"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/GameCard.tsx",
                        lineNumber: 79,
                        columnNumber: 11
                    }, this) : null
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/GameCard.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "mt-2.5 sm:mt-[18px] line-clamp-2 min-h-8 sm:min-h-10 font-head text-xs sm:text-base font-extrabold leading-tight sm:leading-5 text-bp-muted",
                children: game.name
            }, void 0, false, {
                fileName: "[project]/src/components/GameCard.tsx",
                lineNumber: 85,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-1.5 sm:mt-2.5 flex items-center gap-1.5 sm:gap-2.5 text-xs sm:text-sm text-bp-muted",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("i", {
                        className: `size-2 sm:size-[11px] shrink-0 rounded-full ${isIndisponivel ? 'bg-gray-500' : isGratis ? 'bg-green-400' : 'bg-bp-primary'}`
                    }, void 0, false, {
                        fileName: "[project]/src/components/GameCard.tsx",
                        lineNumber: 90,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "min-w-0 truncate text-[11px] sm:text-sm",
                        children: isIndisponivel ? 'Sem oferta ativa' : game.store || 'Loja parceira'
                    }, void 0, false, {
                        fileName: "[project]/src/components/GameCard.tsx",
                        lineNumber: 99,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/GameCard.tsx",
                lineNumber: 89,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-auto pt-2 sm:pt-3.5",
                children: !isIndisponivel && game.price > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        game.originalPrice && game.originalPrice > game.price && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-[9px] sm:text-[10px] text-bp-muted/[.58] line-through",
                            children: brl(game.originalPrice)
                        }, void 0, false, {
                            fileName: "[project]/src/components/GameCard.tsx",
                            lineNumber: 109,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-0.5 font-head text-xs sm:text-sm font-extrabold text-bp-primary",
                            children: brl(game.price)
                        }, void 0, false, {
                            fileName: "[project]/src/components/GameCard.tsx",
                            lineNumber: 113,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/GameCard.tsx",
                    lineNumber: 107,
                    columnNumber: 11
                }, this) : isGratis ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        game.originalPrice && game.originalPrice > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "text-[9px] sm:text-[10px] text-bp-muted/[.58] line-through",
                            children: brl(game.originalPrice)
                        }, void 0, false, {
                            fileName: "[project]/src/components/GameCard.tsx",
                            lineNumber: 120,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-0.5 font-head text-xs sm:text-base font-extrabold text-green-400 tracking-wide",
                            children: "Grátis"
                        }, void 0, false, {
                            fileName: "[project]/src/components/GameCard.tsx",
                            lineNumber: 124,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/GameCard.tsx",
                    lineNumber: 118,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mt-0.5 font-head text-[10px] sm:text-xs font-semibold text-bp-muted/60 uppercase",
                    children: "Indisponível"
                }, void 0, false, {
                    fileName: "[project]/src/components/GameCard.tsx",
                    lineNumber: 129,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/GameCard.tsx",
                lineNumber: 105,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/GameCard.tsx",
        lineNumber: 45,
        columnNumber: 5
    }, this);
}
_s(GameCard, "pw4fIEf/FF+YDWZ1b0pM6q/I2RA=");
_c = GameCard;
var _c;
__turbopack_context__.k.register(_c, "GameCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Icons.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ArrowRight",
    ()=>ArrowRight,
    "AtIcon",
    ()=>AtIcon,
    "BellIcon",
    ()=>BellIcon,
    "BoltIcon",
    ()=>BoltIcon,
    "EyeIcon",
    ()=>EyeIcon,
    "EyeOffIcon",
    ()=>EyeOffIcon,
    "GamepadIcon",
    ()=>GamepadIcon,
    "HeartIcon",
    ()=>HeartIcon,
    "LockIcon",
    ()=>LockIcon,
    "RestoreIcon",
    ()=>RestoreIcon,
    "SearchIcon",
    ()=>SearchIcon,
    "SteamIcon",
    ()=>SteamIcon,
    "StoreIcon",
    ()=>StoreIcon,
    "TagIcon",
    ()=>TagIcon,
    "UserIcon",
    ()=>UserIcon,
    "UserPlusIcon",
    ()=>UserPlusIcon,
    "UserPlusSmall",
    ()=>UserPlusSmall,
    "VisitorIcon",
    ()=>VisitorIcon
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const base = {
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.8,
    strokeLinecap: 'round',
    strokeLinejoin: 'round'
};
// Classe reutilizável para efeito de hover e clique tátil
const interativo = 'transition-transform duration-150 hover:scale-110 active:scale-90 cursor-pointer';
const SearchIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "28",
        height: "28",
        viewBox: "0 0 24 24",
        ...base,
        className: className,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "11",
                cy: "11",
                r: "7"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 24,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M20 20l-4-4"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 25,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 23,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c = SearchIcon;
const BellIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "30",
        height: "30",
        viewBox: "0 0 24 24",
        ...base,
        className: `${interativo} hover:rotate-12 ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 41,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M13.7 21a2 2 0 01-3.4 0"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 42,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 33,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c1 = BellIcon;
const UserPlusIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "22",
        height: "18",
        viewBox: "0 0 24 20",
        ...base,
        className: `${interativo} ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "9",
                cy: "6",
                r: "4"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 51,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M1.5 19c0-4 3.2-6.5 7.5-6.5s7.5 2.5 7.5 6.5"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 52,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M20 5v6M17 8h6"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 53,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 50,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c2 = UserPlusIcon;
const BoltIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "30",
        height: "40",
        viewBox: "0 0 24 32",
        fill: "currentColor",
        className: `${interativo} ${className}`,
        ...p,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M14 0L1 18h9l-3 14L23 12h-9z"
        }, void 0, false, {
            fileName: "[project]/src/components/Icons.tsx",
            lineNumber: 62,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 61,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c3 = BoltIcon;
const TagIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "40",
        height: "40",
        viewBox: "0 0 24 24",
        fill: "currentColor",
        className: `${interativo} ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M3 12.5V4a1 1 0 011-1h8.5a1 1 0 01.7.3l8 8a1 1 0 010 1.4l-8.5 8.5a1 1 0 01-1.4 0l-8-8a1 1 0 01-.3-.7z"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 71,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "8",
                cy: "8",
                r: "1.6",
                fill: "#150c09"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 72,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 70,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c4 = TagIcon;
const AtIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "15",
        height: "15",
        viewBox: "0 0 24 24",
        ...base,
        className: `${interativo} ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "12",
                cy: "12",
                r: "4"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 81,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M16 8v5a3 3 0 006 0v-1a10 10 0 10-3.9 7.9"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 82,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 80,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c5 = AtIcon;
const LockIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "14",
        height: "16",
        viewBox: "0 0 24 24",
        ...base,
        className: `${interativo} ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("rect", {
                x: "4",
                y: "11",
                width: "16",
                height: "10",
                rx: "2"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 91,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M8 11V7a4 4 0 018 0v4"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 92,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 90,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c6 = LockIcon;
const EyeIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "17",
        height: "12",
        viewBox: "0 0 24 24",
        ...base,
        className: `${interativo} ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 101,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "12",
                cy: "12",
                r: "3"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 102,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 100,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c7 = EyeIcon;
const EyeOffIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "17",
        height: "12",
        viewBox: "0 0 24 24",
        ...base,
        className: `${interativo} ${className}`,
        ...p,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M17.9 17.9A10.9 10.9 0 0112 20C5 20 1 12 1 12a18.5 18.5 0 015.1-5.9M9.9 4.2A9.1 9.1 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.2 3.2M1 1l22 22"
        }, void 0, false, {
            fileName: "[project]/src/components/Icons.tsx",
            lineNumber: 111,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 110,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c8 = EyeOffIcon;
const GamepadIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "15",
        height: "11",
        viewBox: "0 0 24 24",
        ...base,
        className: `${interativo} ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M6 12h4M8 10v4"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 120,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "15",
                cy: "11",
                r: ".8"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 121,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "18",
                cy: "13",
                r: ".8"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 122,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M17.3 5H6.7a4 4 0 00-3.9 3.2l-1.7 8A3 3 0 006 19l2-2h8l2 2a3 3 0 004.9-2.8l-1.7-8A4 4 0 0017.3 5z"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 123,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 119,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c9 = GamepadIcon;
const RestoreIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "15",
        height: "15",
        viewBox: "0 0 24 24",
        ...base,
        className: `${interativo} ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M3 12a9 9 0 109-9 9 9 0 00-6.4 2.7L3 8"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 132,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M3 3v5h5M12 8v4l3 2"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 133,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 131,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c10 = RestoreIcon;
const ArrowRight = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "12",
        height: "12",
        viewBox: "0 0 24 24",
        ...base,
        strokeWidth: 2.4,
        className: `${interativo} ${className}`,
        ...p,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M5 12h14M13 5l7 7-7 7"
        }, void 0, false, {
            fileName: "[project]/src/components/Icons.tsx",
            lineNumber: 142,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 141,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c11 = ArrowRight;
const VisitorIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "12",
        height: "12",
        viewBox: "0 0 24 24",
        ...base,
        className: `${interativo} ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "12",
                cy: "7",
                r: "4"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 151,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M4 21c0-4 3.5-6 8-6s8 2 8 6z"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 152,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 150,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c12 = VisitorIcon;
const UserPlusSmall = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "20",
        height: "15",
        viewBox: "0 0 24 20",
        ...base,
        className: `${interativo} ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "9",
                cy: "6",
                r: "4"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 161,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M1.5 19c0-4 3.2-6.5 7.5-6.5s7.5 2.5 7.5 6.5"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 162,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M20 5v6M17 8h6"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 163,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 160,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c13 = UserPlusSmall;
const SteamIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "20",
        height: "20",
        viewBox: "0 0 24 24",
        fill: "currentColor",
        className: `${interativo} ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "12",
                cy: "12",
                r: "11",
                fill: "#fff"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 172,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                fill: "#0088ff",
                d: "M12 4.5a7.5 7.5 0 00-7.4 6.2l4 1.7a2.3 2.3 0 011.3-.4l1.8-2.6a3 3 0 113 3l-2.6 1.9a2.3 2.3 0 01-4.5.4l-2.9-1.2A7.5 7.5 0 1012 4.5z"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 173,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 171,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c14 = SteamIcon;
const HeartIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "16",
        height: "16",
        viewBox: "0 0 24 24",
        ...base,
        className: `${interativo} ${className}`,
        ...p,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            d: "M20.8 4.6a5.5 5.5 0 00-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 00-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 000-7.8z"
        }, void 0, false, {
            fileName: "[project]/src/components/Icons.tsx",
            lineNumber: 182,
            columnNumber: 5
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 181,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c15 = HeartIcon;
const UserIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "14",
        height: "16",
        viewBox: "0 0 24 24",
        ...base,
        className: `${interativo} ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                cx: "12",
                cy: "7",
                r: "4"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 191,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M4 21c0-4 3.5-6 8-6s8 2 8 6"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 192,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 190,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c16 = UserIcon;
const StoreIcon = ({ className = '', ...p })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        width: "40",
        height: "40",
        viewBox: "0 0 24 24",
        fill: "currentColor",
        className: `${interativo} ${className}`,
        ...p,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M4 3h16l2 6a3 3 0 01-5 2 3 3 0 01-5 0 3 3 0 01-5 0 3 3 0 01-5-2z"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 201,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                d: "M4 13.5V21h6v-5h4v5h6v-7.5a5 5 0 01-4-1.3 5 5 0 01-4 1.3 5 5 0 01-4-1.3 5 5 0 01-4 1.3z"
            }, void 0, false, {
                fileName: "[project]/src/components/Icons.tsx",
                lineNumber: 202,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Icons.tsx",
        lineNumber: 200,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
_c17 = StoreIcon;
var _c, _c1, _c2, _c3, _c4, _c5, _c6, _c7, _c8, _c9, _c10, _c11, _c12, _c13, _c14, _c15, _c16, _c17;
__turbopack_context__.k.register(_c, "SearchIcon");
__turbopack_context__.k.register(_c1, "BellIcon");
__turbopack_context__.k.register(_c2, "UserPlusIcon");
__turbopack_context__.k.register(_c3, "BoltIcon");
__turbopack_context__.k.register(_c4, "TagIcon");
__turbopack_context__.k.register(_c5, "AtIcon");
__turbopack_context__.k.register(_c6, "LockIcon");
__turbopack_context__.k.register(_c7, "EyeIcon");
__turbopack_context__.k.register(_c8, "EyeOffIcon");
__turbopack_context__.k.register(_c9, "GamepadIcon");
__turbopack_context__.k.register(_c10, "RestoreIcon");
__turbopack_context__.k.register(_c11, "ArrowRight");
__turbopack_context__.k.register(_c12, "VisitorIcon");
__turbopack_context__.k.register(_c13, "UserPlusSmall");
__turbopack_context__.k.register(_c14, "SteamIcon");
__turbopack_context__.k.register(_c15, "HeartIcon");
__turbopack_context__.k.register(_c16, "UserIcon");
__turbopack_context__.k.register(_c17, "StoreIcon");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/Nav.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Nav
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/image-component.js [app-client] (ecmascript) <export Image as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/search.mjs [app-client] (ecmascript) <export default as Search>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bot$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/bot.mjs [app-client] (ecmascript) <export default as Bot>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2d$clock$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__History$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/rotate-ccw-clock.mjs [app-client] (ecmascript) <export default as History>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/x.mjs [app-client] (ecmascript) <export default as X>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__ = __turbopack_context__.i("[project]/node_modules/lucide-react/dist/esm/icons/menu.mjs [app-client] (ecmascript) <export default as Menu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$assets$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/assets.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Icons.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase.ts/client.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mocks$2f$tema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/mocks/tema.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
;
;
;
;
;
const CHAVE_HISTORICO_BUSCA = 'bp_historico_buscas';
const MAX_HISTORICO = 6;
function Nav({ onSearch, valorBusca = '', modoInicial = 'nativa', logado = false }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const [texto, setTexto] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(valorBusca);
    const [modo, setModo] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(modoInicial);
    const [estaLogado, setEstaLogado] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(logado);
    const [naoLidas, setNaoLidas] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [historico, setHistorico] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [menuAberto, setMenuAberto] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [menuMobileAberto, setMenuMobileAberto] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [buscaMobileAberta, setBuscaMobileAberta] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const containerBuscaRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const menuGavetaRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Carrega buscas recentes do localStorage
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Nav.useEffect": ()=>{
            try {
                const salvo = localStorage.getItem(CHAVE_HISTORICO_BUSCA);
                if (salvo) {
                    const parsed = JSON.parse(salvo);
                    if (Array.isArray(parsed)) {
                        setHistorico(parsed.filter({
                            "Nav.useEffect": (item)=>typeof item === 'string' && item.trim().length > 0
                        }["Nav.useEffect"]));
                    }
                }
            } catch  {
            // Ignora erro em ambientes restritos
            }
        }
    }["Nav.useEffect"], []);
    // Fecha o dropdown se clicar fora
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Nav.useEffect": ()=>{
            function cliqueFora(e) {
                if (containerBuscaRef.current && !containerBuscaRef.current.contains(e.target)) {
                    setMenuAberto(false);
                }
                if (menuGavetaRef.current && !menuGavetaRef.current.contains(e.target)) {
                    setMenuMobileAberto(false);
                }
            }
            document.addEventListener('mousedown', cliqueFora);
            return ({
                "Nav.useEffect": ()=>document.removeEventListener('mousedown', cliqueFora)
            })["Nav.useEffect"];
        }
    }["Nav.useEffect"], []);
    const salvarNoHistorico = (termo)=>{
        const t = termo.trim();
        if (!t) return;
        setHistorico((antigo)=>{
            const filtrado = antigo.filter((item)=>item.toLowerCase() !== t.toLowerCase());
            const novo = [
                t,
                ...filtrado
            ].slice(0, MAX_HISTORICO);
            try {
                localStorage.setItem(CHAVE_HISTORICO_BUSCA, JSON.stringify(novo));
            } catch  {}
            return novo;
        });
    };
    const removerDoHistorico = (e, termoParaRemover)=>{
        e.stopPropagation();
        setHistorico((antigo)=>{
            const novo = antigo.filter((item)=>item !== termoParaRemover);
            try {
                localStorage.setItem(CHAVE_HISTORICO_BUSCA, JSON.stringify(novo));
            } catch  {}
            return novo;
        });
    };
    const limparTodoHistorico = (e)=>{
        e.stopPropagation();
        setHistorico([]);
        try {
            localStorage.removeItem(CHAVE_HISTORICO_BUSCA);
        } catch  {}
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Nav.useEffect": ()=>{
            setTexto(valorBusca || searchParams.get('search') || searchParams.get('busca') || '');
        }
    }["Nav.useEffect"], [
        valorBusca,
        searchParams
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Nav.useEffect": ()=>{
            const modoUrl = searchParams.get('modo');
            if (modoUrl === 'nativa' || modoUrl === 'ia') {
                setModo(modoUrl);
            }
        }
    }["Nav.useEffect"], [
        searchParams
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Nav.useEffect": ()=>{
            setEstaLogado(logado);
        }
    }["Nav.useEffect"], [
        logado
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Nav.useEffect": ()=>{
            if (!estaLogado) return;
            const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts$2f$client$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createClient"])();
            async function carregarNotificacoesNaoLidas() {
                try {
                    const { data: { user } } = await supabase.auth.getUser();
                    if (!user) return;
                    const { count } = await supabase.from('notificacoes').select('*', {
                        count: 'exact',
                        head: true
                    }).eq('usuario_id', user.id).eq('lida', false);
                    if (count !== null) setNaoLidas(count);
                } catch  {
                // Ignora erro se tabela não existir
                }
            }
            carregarNotificacoesNaoLidas();
        }
    }["Nav.useEffect"], [
        estaLogado
    ]);
    const dispararBusca = (termo, modoAtual)=>{
        salvarNoHistorico(termo);
        setMenuAberto(false);
        setBuscaMobileAberta(false);
        if (onSearch) {
            onSearch(termo, modoAtual);
            return;
        }
        if (!termo) return;
        router.push(`/jogos?search=${encodeURIComponent(termo)}&modo=${modoAtual}`);
    };
    const pesquisar = (e)=>{
        e.preventDefault();
        dispararBusca(texto.trim(), modo);
    };
    const selecionarDoHistorico = (item)=>{
        setTexto(item);
        dispararBusca(item, modo);
    };
    const alterarModo = (novoModo)=>{
        setModo(novoModo);
        const termo = texto.trim();
        if (termo) {
            dispararBusca(termo, novoModo);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "w-full shrink-0 bg-bp-nav",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: "flex h-16 sm:h-20 items-center justify-between gap-3 px-3.5 sm:px-5 sm:gap-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        "aria-label": "BananaPrice",
                        className: "relative h-[48px] w-[140px] sm:h-[88px] sm:w-[270px] shrink-0 overflow-hidden transition-transform duration-150 active:scale-95 max-[1100px]:w-[180px]",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__["default"], {
                            src: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$assets$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["logo"],
                            alt: "BananaPrice",
                            width: 303,
                            height: 101,
                            priority: true,
                            className: "absolute -left-3 -top-1.5 h-[62px] w-[186px] sm:-left-4 sm:-top-1.5 sm:h-[101px] sm:w-[303px] max-w-none object-contain sm:object-cover"
                        }, void 0, false, {
                            fileName: "[project]/src/components/Nav.tsx",
                            lineNumber: 208,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/Nav.tsx",
                        lineNumber: 203,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 sm:hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setBuscaMobileAberta((v)=>!v),
                                "aria-label": buscaMobileAberta ? 'Fechar busca' : 'Abrir busca',
                                className: "inline-flex size-9 items-center justify-center rounded-[9px] border border-bp-muted/30 bg-bp-nav/90 text-bp-primary shadow-sm transition active:scale-95",
                                children: buscaMobileAberta ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                    className: "size-5"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Nav.tsx",
                                    lineNumber: 227,
                                    columnNumber: 34
                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                    className: "size-5"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Nav.tsx",
                                    lineNumber: 227,
                                    columnNumber: 61
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/Nav.tsx",
                                lineNumber: 221,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setMenuMobileAberto((v)=>!v),
                                "aria-label": "Abrir menu",
                                className: "relative inline-flex size-9 items-center justify-center rounded-[9px] bg-bp-primary text-bp-neutral shadow-sm transition active:scale-95",
                                children: [
                                    menuMobileAberto ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                        className: "size-5"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Nav.tsx",
                                        lineNumber: 237,
                                        columnNumber: 33
                                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$menu$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Menu$3e$__["Menu"], {
                                        className: "size-5"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Nav.tsx",
                                        lineNumber: 237,
                                        columnNumber: 60
                                    }, this),
                                    naoLidas > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute -right-1 -top-1 flex size-3.5 items-center justify-center rounded-full bg-red-500 font-head text-[9px] font-bold text-white ring-2 ring-bp-nav",
                                        children: naoLidas > 9 ? '9+' : naoLidas
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Nav.tsx",
                                        lineNumber: 239,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Nav.tsx",
                                lineNumber: 231,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Nav.tsx",
                        lineNumber: 219,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        role: "search",
                        onSubmit: pesquisar,
                        className: `${buscaMobileAberta ? 'flex' : 'hidden'} sm:flex absolute left-0 right-0 top-full z-40 bg-bp-nav p-3 border-b border-[#3d322e] shadow-2xl sm:static sm:z-auto sm:border-none sm:bg-transparent sm:p-0 sm:shadow-none sm:max-w-[580px] sm:flex-1 sm:items-center sm:gap-2`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                ref: containerBuscaRef,
                                className: "relative flex-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                        type: "search",
                                        name: "search",
                                        autoComplete: "off",
                                        autoCorrect: "off",
                                        spellCheck: false,
                                        placeholder: modo === 'nativa' ? 'Busca rápida de jogos (ex: Resident Evil)...' : 'Busca profunda com IA...',
                                        "aria-label": "Buscar jogos",
                                        maxLength: 100,
                                        value: texto,
                                        onFocus: ()=>{
                                            if (historico.length > 0) setMenuAberto(true);
                                        },
                                        onChange: (e)=>{
                                            setTexto(e.target.value);
                                            if (historico.length > 0 && !menuAberto) setMenuAberto(true);
                                        },
                                        className: "h-[42px] sm:h-[46px] w-full rounded-[11px] sm:rounded-[13px] border border-bp-muted/30 bg-bp-nav pl-[14px] sm:pl-[18px] pr-[44px] sm:pr-[52px] text-xs text-bp-text outline-none placeholder:text-bp-muted/45 focus:border-bp-primary transition-colors"
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Nav.tsx",
                                        lineNumber: 255,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "submit",
                                        "aria-label": "Pesquisar",
                                        title: "Pesquisar",
                                        className: "absolute right-3.5 sm:right-4 top-1/2 -translate-y-1/2 cursor-pointer text-[#817667]/90 transition-colors hover:text-bp-primary",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SearchIcon"], {}, void 0, false, {
                                            fileName: "[project]/src/components/Nav.tsx",
                                            lineNumber: 284,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Nav.tsx",
                                        lineNumber: 278,
                                        columnNumber: 13
                                    }, this),
                                    menuAberto && historico.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute left-0 right-0 top-[calc(100%+6px)] z-50 overflow-hidden rounded-[13px] border border-[#3d322e] bg-bp-surface shadow-2xl backdrop-blur-md",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center justify-between border-b border-[#3d322e]/60 px-3.5 py-2 text-[11px] text-bp-muted/70",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "flex items-center gap-1.5 font-head font-bold uppercase tracking-wider text-bp-primary/90",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2d$clock$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__History$3e$__["History"], {
                                                                className: "size-3"
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/Nav.tsx",
                                                                lineNumber: 292,
                                                                columnNumber: 21
                                                            }, this),
                                                            " Buscas Recentes"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/src/components/Nav.tsx",
                                                        lineNumber: 291,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        onClick: limparTodoHistorico,
                                                        className: "cursor-pointer text-[10px] text-bp-muted/50 hover:text-bp-primary transition-colors",
                                                        children: "Limpar tudo"
                                                    }, void 0, false, {
                                                        fileName: "[project]/src/components/Nav.tsx",
                                                        lineNumber: 294,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/src/components/Nav.tsx",
                                                lineNumber: 290,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                                className: "flex flex-col py-1",
                                                children: historico.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                        onClick: ()=>selecionarDoHistorico(item),
                                                        className: "group flex cursor-pointer items-center justify-between px-3.5 py-2 text-xs text-bp-text hover:bg-bp-nav/80 hover:text-bp-primary transition-colors",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center gap-2.5 truncate pr-2",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$rotate$2d$ccw$2d$clock$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__History$3e$__["History"], {
                                                                        className: "size-3.5 shrink-0 text-bp-muted/40 group-hover:text-bp-primary"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/Nav.tsx",
                                                                        lineNumber: 311,
                                                                        columnNumber: 25
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "truncate",
                                                                        children: item
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/src/components/Nav.tsx",
                                                                        lineNumber: 312,
                                                                        columnNumber: 25
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/src/components/Nav.tsx",
                                                                lineNumber: 310,
                                                                columnNumber: 23
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                type: "button",
                                                                onClick: (e)=>removerDoHistorico(e, item),
                                                                title: "Remover do histórico",
                                                                className: "opacity-40 hover:opacity-100 hover:text-rose-400 p-1 transition-opacity",
                                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$x$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__X$3e$__["X"], {
                                                                    className: "size-3"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/src/components/Nav.tsx",
                                                                    lineNumber: 320,
                                                                    columnNumber: 25
                                                                }, this)
                                                            }, void 0, false, {
                                                                fileName: "[project]/src/components/Nav.tsx",
                                                                lineNumber: 314,
                                                                columnNumber: 23
                                                            }, this)
                                                        ]
                                                    }, item, true, {
                                                        fileName: "[project]/src/components/Nav.tsx",
                                                        lineNumber: 305,
                                                        columnNumber: 21
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Nav.tsx",
                                                lineNumber: 303,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Nav.tsx",
                                        lineNumber: 289,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Nav.tsx",
                                lineNumber: 254,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex h-[42px] sm:h-[46px] shrink-0 items-center rounded-[11px] sm:rounded-[13px] border border-bp-muted/30 bg-bp-nav/80 p-0.5 sm:p-1 ml-2 sm:ml-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>alterarModo('nativa'),
                                        title: "Busca Rápida e Direta (estilo Steam)",
                                        className: `flex h-full items-center gap-1 sm:gap-1.5 rounded-[8px] sm:rounded-[9px] px-2 sm:px-2.5 font-head text-[11px] font-bold transition-all duration-150 active:scale-95 ${modo === 'nativa' ? 'bg-bp-primary text-bp-neutral shadow-sm' : 'text-bp-muted hover:text-bp-primary'}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$search$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Search$3e$__["Search"], {
                                                className: "size-3.5"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Nav.tsx",
                                                lineNumber: 341,
                                                columnNumber: 15
                                            }, this),
                                            " Nativa"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Nav.tsx",
                                        lineNumber: 331,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>alterarModo('ia'),
                                        title: "Busca Avançada de Franquias e Sequências com IA",
                                        className: `flex h-full items-center gap-1 sm:gap-1.5 rounded-[8px] sm:rounded-[9px] px-2 sm:px-2.5 font-head text-[11px] font-bold transition-all duration-150 active:scale-95 ${modo === 'ia' ? 'bg-bp-primary text-bp-neutral shadow-sm' : 'text-bp-muted hover:text-bp-primary'}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lucide$2d$react$2f$dist$2f$esm$2f$icons$2f$bot$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Bot$3e$__["Bot"], {
                                                className: "size-3.5"
                                            }, void 0, false, {
                                                fileName: "[project]/src/components/Nav.tsx",
                                                lineNumber: 353,
                                                columnNumber: 15
                                            }, this),
                                            " IA"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/src/components/Nav.tsx",
                                        lineNumber: 343,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Nav.tsx",
                                lineNumber: 330,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Nav.tsx",
                        lineNumber: 247,
                        columnNumber: 9
                    }, this),
                    estaLogado ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "hidden sm:flex shrink-0 items-center gap-3 lg:gap-[19px] pr-2.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/notificacoes",
                                "aria-label": "Notificações",
                                className: "relative inline-flex size-[38px] items-center justify-center rounded-[9px] bg-bp-primary text-bp-neutral shadow-sm transition-all duration-150 hover:brightness-110 active:scale-95",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BellIcon"], {
                                        width: 20,
                                        height: 20
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Nav.tsx",
                                        lineNumber: 366,
                                        columnNumber: 15
                                    }, this),
                                    naoLidas > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute -right-1.5 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-red-500 px-1 font-head text-[10px] font-extrabold text-white ring-2 ring-bp-nav",
                                        "aria-label": `${naoLidas} notificações não lidas`,
                                        children: naoLidas > 99 ? '99+' : naoLidas
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/Nav.tsx",
                                        lineNumber: 368,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Nav.tsx",
                                lineNumber: 361,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/lista-de-desejos",
                                className: "inline-flex h-[38px] items-center gap-2 whitespace-nowrap rounded-[9px] bg-bp-primary px-3.5 font-head text-xs font-bold text-bp-neutral shadow-sm transition-all duration-150 hover:brightness-110 active:scale-95",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeartIcon"], {}, void 0, false, {
                                        fileName: "[project]/src/components/Nav.tsx",
                                        lineNumber: 380,
                                        columnNumber: 15
                                    }, this),
                                    " Lista de Desejos"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Nav.tsx",
                                lineNumber: 376,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/conta",
                                className: "inline-flex h-[38px] items-center gap-2 whitespace-nowrap rounded-[9px] bg-bp-primary px-3.5 font-head text-xs font-bold text-bp-neutral shadow-sm transition-all duration-150 hover:brightness-110 active:scale-95",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UserIcon"], {}, void 0, false, {
                                        fileName: "[project]/src/components/Nav.tsx",
                                        lineNumber: 386,
                                        columnNumber: 15
                                    }, this),
                                    " Conta"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/Nav.tsx",
                                lineNumber: 382,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Nav.tsx",
                        lineNumber: 360,
                        columnNumber: 11
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/login",
                        className: "hidden sm:inline-flex h-[38px] items-center gap-2 whitespace-nowrap rounded-[9px] bg-bp-primary px-4 font-head text-xs font-bold text-bp-neutral shadow-sm transition-all duration-150 hover:brightness-110 active:scale-95",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UserPlusIcon"], {}, void 0, false, {
                                fileName: "[project]/src/components/Nav.tsx",
                                lineNumber: 394,
                                columnNumber: 13
                            }, this),
                            "Login / Cadastrar"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Nav.tsx",
                        lineNumber: 390,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Nav.tsx",
                lineNumber: 201,
                columnNumber: 7
            }, this),
            menuMobileAberto && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: menuGavetaRef,
                className: "sm:hidden border-b border-[#3d322e] bg-bp-surface px-4 py-3 shadow-2xl animate-in slide-in-from-top-2 duration-150",
                children: estaLogado ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-2.5",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/notificacoes",
                            onClick: ()=>setMenuMobileAberto(false),
                            className: "flex items-center justify-between rounded-xl bg-bp-neutral px-3.5 py-2.5 text-xs font-bold text-bp-text hover:text-bp-primary transition",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "flex items-center gap-2.5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BellIcon"], {
                                            width: 18,
                                            height: 18,
                                            className: "text-bp-primary"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/Nav.tsx",
                                            lineNumber: 414,
                                            columnNumber: 19
                                        }, this),
                                        " Notificações"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Nav.tsx",
                                    lineNumber: 413,
                                    columnNumber: 17
                                }, this),
                                naoLidas > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "rounded-full bg-red-500 px-2 py-0.5 text-[10px] font-bold text-white",
                                    children: [
                                        naoLidas,
                                        " novas"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/components/Nav.tsx",
                                    lineNumber: 417,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Nav.tsx",
                            lineNumber: 408,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/lista-de-desejos",
                            onClick: ()=>setMenuMobileAberto(false),
                            className: "flex items-center gap-2.5 rounded-xl bg-bp-neutral px-3.5 py-2.5 text-xs font-bold text-bp-text hover:text-bp-primary transition",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["HeartIcon"], {
                                    className: "text-bp-primary"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Nav.tsx",
                                    lineNumber: 427,
                                    columnNumber: 17
                                }, this),
                                " Lista de Desejos"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Nav.tsx",
                            lineNumber: 422,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/conta",
                            onClick: ()=>setMenuMobileAberto(false),
                            className: "flex items-center gap-2.5 rounded-xl bg-bp-neutral px-3.5 py-2.5 text-xs font-bold text-bp-text hover:text-bp-primary transition",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UserIcon"], {
                                    className: "text-bp-primary"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/Nav.tsx",
                                    lineNumber: 434,
                                    columnNumber: 17
                                }, this),
                                " Minha Conta"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/Nav.tsx",
                            lineNumber: 429,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/Nav.tsx",
                    lineNumber: 407,
                    columnNumber: 13
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-2",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/login",
                        onClick: ()=>setMenuMobileAberto(false),
                        className: "flex items-center justify-center gap-2 rounded-xl bg-bp-primary px-4 py-2.5 font-head text-xs font-bold text-bp-neutral shadow-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Icons$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["UserPlusIcon"], {}, void 0, false, {
                                fileName: "[project]/src/components/Nav.tsx",
                                lineNumber: 444,
                                columnNumber: 17
                            }, this),
                            " Fazer Login / Cadastrar"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/Nav.tsx",
                        lineNumber: 439,
                        columnNumber: 15
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/Nav.tsx",
                    lineNumber: 438,
                    columnNumber: 13
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/Nav.tsx",
                lineNumber: 402,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-[5px] w-full",
                style: {
                    background: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$mocks$2f$tema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["tema"].divisor
                }
            }, void 0, false, {
                fileName: "[project]/src/components/Nav.tsx",
                lineNumber: 452,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Nav.tsx",
        lineNumber: 200,
        columnNumber: 5
    }, this);
}
_s(Nav, "aSrjaMBT4qlYJD1Qgk5UUUCNXyc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = Nav;
var _c;
__turbopack_context__.k.register(_c, "Nav");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/assets.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Imagens ficam em /public/assets
__turbopack_context__.s([
    "bananas",
    ()=>bananas,
    "capaExemplo",
    ()=>capaExemplo,
    "contatoEApiImg",
    ()=>contatoEApiImg,
    "logo",
    ()=>logo,
    "macaco",
    ()=>macaco,
    "macacoFeliz",
    ()=>macacoFeliz,
    "macacobanana",
    ()=>macacobanana,
    "macacotudo",
    ()=>macacotudo,
    "palmeira",
    ()=>palmeira,
    "politicaDePrivacidadeImg",
    ()=>politicaDePrivacidadeImg,
    "termosDeUsoImg",
    ()=>termosDeUsoImg
]);
const logo = '/assets/logo.svg';
const palmeira = '/assets/palmeira.png';
const bananas = '/assets/bananas.png';
const macaco = '/assets/macaco.png';
const capaExemplo = '/assets/capa-exemplo.png';
const macacotudo = '/assets/macacotudo.svg';
const macacobanana = '/assets/macacobanana.svg';
const macacoFeliz = '/assets/macaco.svg';
const termosDeUsoImg = '/assets/termosdeUso.png';
const politicaDePrivacidadeImg = '/assets/politicadePrivacidade.png';
const contatoEApiImg = '/assets/contatoeAPI.png';
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/components/loading.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Loading
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/image-component.js [app-client] (ecmascript) <export Image as default>");
'use client';
;
;
function Loading({ mensagem = 'Carregando...', tamanho = 200 }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col items-center justify-center py-10 gap-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$image$2d$component$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Image__as__default$3e$__["default"], {
                src: "/assets/loading.gif",
                alt: "Carregando...",
                width: tamanho,
                height: tamanho,
                unoptimized: true,
                className: "object-contain"
            }, void 0, false, {
                fileName: "[project]/src/components/loading.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            mensagem && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "font-head text-sm font-semibold text-bp-muted animate-pulse",
                children: mensagem
            }, void 0, false, {
                fileName: "[project]/src/components/loading.tsx",
                lineNumber: 25,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/loading.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
_c = Loading;
var _c;
__turbopack_context__.k.register(_c, "Loading");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/adulto/index.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "adultoAtivoNoNavegador",
    ()=>adultoAtivoNoNavegador,
    "adultoPermitido",
    ()=>adultoPermitido,
    "definirAdultoNoNavegador",
    ()=>definirAdultoNoNavegador
]);
const COOKIE = "bp_adulto";
function adultoPermitido(request) {
    const cookie = request.headers.get("cookie") ?? "";
    return new RegExp(`(?:^|;\\s*)${COOKIE}=1(?:;|$)`).test(cookie);
}
function adultoAtivoNoNavegador() {
    if (typeof document === "undefined") return false;
    return document.cookie.split("; ").includes(`${COOKIE}=1`);
}
function definirAdultoNoNavegador(ativo) {
    document.cookie = ativo ? `${COOKIE}=1; max-age=31536000; path=/; SameSite=Lax` : `${COOKIE}=; max-age=0; path=/; SameSite=Lax`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/hardwareGiftCard.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ehConsoleOuGiftCard",
    ()=>ehConsoleOuGiftCard
]);
/**
 * Padrões de expressões regulares que identificam itens que são Hardware,
 * Consoles ou Gift Cards / Moedas / Assinaturas (não sendo jogos em si).
 */ const PADROES_HARDWARE_GIFTCARD = [
    // Gift cards e cartões de saldo / moedas virtuais / assinaturas de loja
    /\bgift\s*cards?\b/i,
    /\bcart(a|ã)o\s+presente\b/i,
    /\be?shop\s*cards?\b/i,
    /\bwallet\s*(cards?|top-?up|code)\b/i,
    /\bpsn\s*(cards?|voucher|code|plus)\b/i,
    /\bplaystation\s+store\s+card\b/i,
    /\bplaystation\s+network\s+card\b/i,
    /\bxbox\s+live\s*(gold)?\s*(cards?|code)?\b/i,
    /\bxbox\s+game\s*pass\b/i,
    /\bgame\s*pass\s+ultimate\b/i,
    /\b(nintendo|playstation|xbox|steam|razer|roblox|blizzard)\s+gift\b/i,
    /\broblox\s+(gift\s*card|robux)\b/i,
    // Consoles e hardware
    /\bconsoles?\b/i,
    /\bplaystation\s*5(\s+pro|\s+slim)?(\s+edition)?\b/i,
    /\bps5(\s+pro|\s+slim)?(\s+console)?\b/i,
    /\bplaystation\s*4(\s+pro|\s+slim)?(\s+console)?\b/i,
    /\bps4(\s+pro|\s+slim)?(\s+console)?\b/i,
    /\bxbox\s+series\s+[xs](\s+console)?\b/i,
    /\bxbox\s+one\s+[xs]?(\s+console)?\b/i,
    /\bnintendo\s+switch(\s+oled|\s+lite)?(\s+model|\s+console)?\b/i,
    /\bsteam\s+deck(\s+oled)?\b/i,
    /\bmeta\s+quest(\s+[23])?\b/i,
    /\boculus\s+quest\b/i,
    /\bdualsense(\s+wireless\s+controller)?\b/i,
    /\bjoy-?con\b/i
];
function ehConsoleOuGiftCard(titulo) {
    if (!titulo) return false;
    const t = titulo.trim();
    return PADROES_HARDWARE_GIFTCARD.some((regex)=>regex.test(t));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/itad.ts/index.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buscarCapa",
    ()=>buscarCapa,
    "buscarGenero",
    ()=>buscarGenero,
    "buscarInfoBasica",
    ()=>buscarInfoBasica,
    "buscarInfoJogo",
    ()=>buscarInfoJogo,
    "buscarItadIdsPorSteamAppIds",
    ()=>buscarItadIdsPorSteamAppIds,
    "buscarLinksOfertas",
    ()=>buscarLinksOfertas,
    "buscarOfertasJogo",
    ()=>buscarOfertasJogo,
    "buscarOfertasSteam",
    ()=>buscarOfertasSteam,
    "buscarPaginaJogos",
    ()=>buscarPaginaJogos,
    "buscarPrecosLote",
    ()=>buscarPrecosLote,
    "linksDasOfertas",
    ()=>linksDasOfertas,
    "slugify",
    ()=>slugify,
    "urlCapaItad",
    ()=>urlCapaItad
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$util$2e$ts$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/util.ts/index.ts [app-client] (ecmascript)");
;
;
const URL_API_ITAD = "https://api.isthereanydeal.com";
const ID_LOJA_STEAM_ITAD = 61;
function obterChaveItad() {
    const chave = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.ITAD_API_KEY;
    if (!chave) {
        throw new Error("ITAD_API_KEY não foi encontrada. Defina no .env da raiz do projeto.");
    }
    return chave;
}
function calcularEspera429(erro) {
    const retryAfter = erro.response?.headers?.["retry-after"];
    if (retryAfter) {
        const segundos = Number(retryAfter);
        if (!isNaN(segundos)) {
            return (segundos + 5) * 1000;
        }
    }
    return 5 * 60 * 1000;
}
function slugify(texto) {
    return texto.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
async function buscarPaginaJogos(ultimoId) {
    console.log("Buscando jogos...");
    const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${URL_API_ITAD}/unstable/games/list/v1`, {
        params: {
            key: obterChaveItad(),
            ...ultimoId && {
                last: ultimoId
            }
        }
    });
    return response.data;
}
async function buscarGenero(itadId) {
    while(true){
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${URL_API_ITAD}/games/info/v2`, {
                params: {
                    id: itadId,
                    key: obterChaveItad()
                }
            });
            const tags = response.data?.tags ?? [];
            return tags.length > 0 ? tags.join(", ") : null;
        } catch (erro) {
            if (erro.response?.status === 429) {
                const tempoEspera = calcularEspera429(erro);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$util$2e$ts$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["esperar"])(tempoEspera);
                continue;
            }
            return null;
        }
    }
}
async function buscarInfoJogo(itadId) {
    while(true){
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${URL_API_ITAD}/games/info/v2`, {
                params: {
                    id: itadId,
                    key: obterChaveItad()
                }
            });
            const tags = response.data?.tags ?? [];
            return {
                genero: tags.length > 0 ? tags.join(", ") : null,
                adulto: response.data?.mature === true
            };
        } catch (erro) {
            if (erro.response?.status === 429) {
                const tempoEspera = calcularEspera429(erro);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$util$2e$ts$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["esperar"])(tempoEspera);
                continue;
            }
            return {
                genero: null,
                adulto: null
            };
        }
    }
}
async function buscarPrecosLote(ids, inicio, fim) {
    while(true){
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(`${URL_API_ITAD}/games/prices/v3`, ids, {
                params: {
                    key: obterChaveItad(),
                    country: "BR"
                }
            });
            return response.data;
        } catch (erro) {
            if (erro.response?.status === 429) {
                const tempoEspera = calcularEspera429(erro);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$util$2e$ts$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["esperar"])(tempoEspera);
                continue;
            }
            throw erro;
        }
    }
}
async function buscarItadIdsPorSteamAppIds(appIds) {
    const resultado = [];
    const tamanhoLote = 200;
    for(let i = 0; i < appIds.length; i += tamanhoLote){
        const lote = appIds.slice(i, i + tamanhoLote).map((appId)=>`app/${appId}`);
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(`${URL_API_ITAD}/lookup/id/shop/${ID_LOJA_STEAM_ITAD}/v1`, lote, {
                params: {
                    key: obterChaveItad()
                }
            });
            const mapa = response.data ?? {};
            for (const itadId of Object.values(mapa)){
                if (itadId) resultado.push(itadId);
            }
        } catch (erro) {
            if (erro.response?.status === 429) break;
        }
    }
    return resultado;
}
/* Cache em memória das ofertas por jogo */ const cacheOfertas = new Map();
const TTL_OFERTAS_MS = 10 * 60 * 1000;
async function buscarOfertasSteam(appid) {
    try {
        console.log(`[STEAM API] Consultando ofertas para appid ${appid}...`);
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`https://store.steampowered.com/api/appdetails`, {
            params: {
                appids: appid,
                cc: "br",
                l: "portuguese"
            },
            timeout: 5000
        });
        const dadosApp = response.data?.[appid];
        if (!dadosApp?.success || !dadosApp?.data) return [];
        const data = dadosApp.data;
        const urlJogo = `https://store.steampowered.com/app/${appid}`;
        if (data.is_free) {
            return [
                {
                    shop: {
                        name: "Steam"
                    },
                    price: {
                        amount: 0
                    },
                    regular: {
                        amount: 0
                    },
                    cut: 0,
                    url: urlJogo
                }
            ];
        }
        const priceOverview = data.price_overview;
        if (!priceOverview) return [];
        const valorAtual = priceOverview.final / 100;
        const valorOriginal = priceOverview.initial / 100;
        const desconto = priceOverview.discount_percent ?? 0;
        return [
            {
                shop: {
                    name: "Steam"
                },
                price: {
                    amount: valorAtual
                },
                regular: {
                    amount: valorOriginal
                },
                cut: desconto,
                url: urlJogo
            }
        ];
    } catch (erro) {
        console.log(`[STEAM API ERRO] Appid ${appid}:`, erro?.message ?? erro);
        return [];
    }
}
async function buscarOfertasJogo(itadId, appid) {
    const emCache = cacheOfertas.get(itadId);
    if (emCache && emCache.expira > Date.now()) {
        return emCache.deals;
    }
    let deals = [];
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(`${URL_API_ITAD}/games/prices/v3`, [
            itadId
        ], {
            params: {
                key: obterChaveItad(),
                country: "BR"
            },
            timeout: 5000
        });
        deals = response.data?.[0]?.deals ?? [];
        console.log(`[ITAD API] ${itadId} retornou ${deals.length} ofertas.`);
    } catch (erro) {
        console.log(`[ITAD API ERRO] ${itadId}:`, erro.response?.data ?? erro.message);
    }
    // Fallback na Steam caso ITAD retorne 0 ofertas
    if (deals.length === 0) {
        let steamAppId = appid;
        if (!steamAppId) {
            const info = await buscarInfoBasica(itadId);
            steamAppId = info.appid;
        }
        if (steamAppId) {
            console.log(`[FALLBACK] 0 ofertas no ITAD. Consultando Steam para appid: ${steamAppId}`);
            deals = await buscarOfertasSteam(steamAppId);
        }
    }
    if (deals.length > 0) {
        cacheOfertas.set(itadId, {
            expira: Date.now() + TTL_OFERTAS_MS,
            deals
        });
    }
    return deals;
}
function linksDasOfertas(deals) {
    const links = {};
    for (const deal of deals){
        const loja = String(deal?.shop?.name ?? "").toLowerCase();
        const url = String(deal?.url ?? "");
        if (loja && url.startsWith("https://")) {
            links[loja] = url;
        }
    }
    return links;
}
async function buscarLinksOfertas(itadId) {
    return linksDasOfertas(await buscarOfertasJogo(itadId));
}
const cacheCapas = new Map();
const TTL_CAPAS_MS = 24 * 60 * 60 * 1000;
async function buscarCapa(itadId) {
    const emCache = cacheCapas.get(itadId);
    if (emCache && emCache.expira > Date.now()) return emCache.capa;
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${URL_API_ITAD}/games/info/v2`, {
            params: {
                id: itadId,
                key: obterChaveItad()
            },
            timeout: 5000
        });
        const assets = response.data?.assets ?? {};
        const url = assets.banner600 ?? assets.banner400 ?? assets.banner300 ?? assets.boxart ?? null;
        const capa = typeof url === "string" && url.startsWith("https://") ? url : null;
        cacheCapas.set(itadId, {
            expira: Date.now() + TTL_CAPAS_MS,
            capa
        });
        return capa;
    } catch  {
        return null;
    }
}
const cacheInfoBasica = new Map();
const TTL_INFO_MS = 24 * 60 * 60 * 1000;
async function buscarInfoBasica(itadId) {
    const emCache = cacheInfoBasica.get(itadId);
    if (emCache && emCache.expira > Date.now()) return emCache.info;
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].get(`${URL_API_ITAD}/games/info/v2`, {
            params: {
                id: itadId,
                key: obterChaveItad()
            },
            timeout: 5000
        });
        const assets = response.data?.assets ?? {};
        const url = assets.banner600 ?? assets.banner400 ?? assets.banner300 ?? assets.boxart ?? null;
        const appid = Number(response.data?.appid);
        const info = {
            capa: typeof url === "string" && url.startsWith("https://") ? url : null,
            appid: Number.isInteger(appid) && appid > 0 ? appid : null
        };
        cacheInfoBasica.set(itadId, {
            expira: Date.now() + TTL_INFO_MS,
            info
        });
        return info;
    } catch  {
        return {
            capa: null,
            appid: null
        };
    }
}
function urlCapaItad(itadId, tamanho = "banner300") {
    return `https://assets.isthereanydeal.com/${itadId}/${tamanho}.jpg`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/supabase.ts/client.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createClient",
    ()=>createClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@supabase/ssr/dist/module/createBrowserClient.js [app-client] (ecmascript)");
;
function createClient() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$ssr$2f$dist$2f$module$2f$createBrowserClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createBrowserClient"])(("TURBOPACK compile-time value", "https://jupiqcmofilnfneqsfqw.supabase.co"), ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp1cGlxY21vZmlsbmZuZXFzZnF3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTA4MTk0NTMsImV4cCI6MjEwNjM5NTQ1M30.nwkiM7V9PEI5S_TJbiJsk-8tmRlIOsYYMvDv2BIuEbg"));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/lib/util.ts/index.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Pausa a execução pelo tempo informado.
 *
 * Usado para esperar entre tentativas, tanto em limites de requisição (rate limits) quanto em falhas transitórias de rede.
 *
 * @param ms Tempo de espera, em milissegundos.
 * @returns Promessa resolvida após o intervalo estipulado.
 */ __turbopack_context__.s([
    "esperar",
    ()=>esperar
]);
function esperar(ms) {
    return new Promise((resolve)=>setTimeout(resolve, ms));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/mocks/promos.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Dados de exemplo da tela /jogos. Trocar pela API (/api/v1/games) quando estiver pronta.
__turbopack_context__.s([
    "CUT_FILTERS",
    ()=>CUT_FILTERS,
    "PER_PAGE",
    ()=>PER_PAGE,
    "PRICE_FILTERS",
    ()=>PRICE_FILTERS,
    "STORES",
    ()=>STORES,
    "promos",
    ()=>promos
]);
const STORES = [
    'Nuuvem',
    'GOG',
    'EA Store',
    'Epic Games Store',
    'Steam'
];
const PRICE_FILTERS = [
    5,
    25,
    50,
    150
];
const CUT_FILTERS = [
    90,
    75,
    50,
    25
];
const PER_PAGE = 12;
const ORIGINALS = [
    30,
    60,
    100,
    150,
    200
];
const DISCOUNTS = [
    25,
    50,
    75,
    80,
    90
];
const promos = Array.from({
    length: 50
}, (_, i)=>{
    const original = ORIGINALS[i % 5];
    const discount = DISCOUNTS[(i * 3 + 1) % 5];
    return {
        id: i + 1,
        name: 'Game Name',
        store: STORES[i % STORES.length],
        original,
        discount,
        price: Math.round(original * (1 - discount / 100) * 100) / 100,
        capa: null
    };
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/mocks/tema.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Cores usadas nas telas que não fazem parte do tema do globals.css (bp-*).
__turbopack_context__.s([
    "tema",
    ()=>tema
]);
const tema = {
    painel: '#3d322e',
    divisor: '#3d322e',
    divisorForte: '#3d3b2e',
    progresso: '#2d6000',
    caixaCarregando: '#140b08'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=src_0m5y_omjf5eo7._.js.map